/*
 * Menu_init.h
 *
 * Created: 18.09.2024 23:11:45
 *  Author: eikel
 */ 


#ifndef MENU_INIT_H
#define MENU_INIT_H

#include "Menu.h"

// Funksjon for � initialisere alle menyane
void initialize_menus();

// Menyobjekt-eksportar


#endif /* MENU_INIT_H */
