/*
 * driver_IR.h
 *
 * Created: 16.10.2024 14:32:43
 *  Author: adriaeik
 */ 


#ifndef DRIVER_IR_H_
#define DRIVER_IR_H_

void IR_Init();
uint16_t IR_Read();
void IR_Handler();


#endif /* DRIVER_IR_H_ */