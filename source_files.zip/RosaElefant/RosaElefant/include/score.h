/*
 * score.h
 *
 * Created: 16.10.2024 15:59:00
 *  Author: adriaeik
 */ 


#ifndef SCORE_H_
#define SCORE_H_

#include "driver_IR.h"

extern uint8_t score = 0;

void add_score(){score++;}




#endif /* SCORE_H_ */