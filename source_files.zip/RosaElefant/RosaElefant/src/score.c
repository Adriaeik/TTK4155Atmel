/*
 * score.c
 *
 * Created: 16.10.2024 15:58:27
 *  Author: adriaeik
 */ 
