/*
 * SRAM.h
 *
 * Created: 04.09.2024 18:44:34
 *  Author: adriaeik
 */ 
//#include <stdlib.h>
#include "Utils.h"

#ifndef SRAM_H_
#define SRAM_H_

void SRAM_test(void);
#endif /* SRAM_H_ */